# Editor Vectorial 2D para Planos de Negocios 

Proyecto desarrollado para el curso de **Computación Gráfica**. Permite a los emprendedores locales diseñar la distribución de sus establecimientos comerciales de manera interactiva utilizando primitivas gráficas, transformaciones 2D y arcos vectoriales.

## 🚀 Características Técnicas
- **Primitivas Gráficas:** Trazado de muros (segmentos de recta con grosor) y mobiliario (rectángulos vectoriales).
- **Transformaciones 2D:** Implementación explícita de Traslación, Rotación y Escalado mediante matrices de transformación y trigonometría aplicada.
- **Sistemas de Coordenadas:** Conversión en tiempo real entre coordenadas de pantalla y coordenadas de mundo real.
- **Persistencia:** Importación y exportación de proyectos en formato JSON y renderizado a imagen PNG.

## 🛠️ Cómo Ejecutar
1. Clona o descarga este repositorio.
2. Ingresa a la carpeta `src/`.
3. Abre el archivo `index.html` en cualquier navegador web moderno (Google Chrome, Firefox, Edge). No requiere instalación de servidores ni dependencias externas.

## 📂 Estructura del Repositorio
- `src/`: Código fuente modular (HTML, CSS y JavaScript).
- `docs/`: Documentación e informe del proyecto.
- `video/`: Enlace al video de demostración.