/**
 * FloorPlanPro 2D - Lógica de Computación Gráfica con HTML5 Canvas
 */

// Constantes globales de renderizado y escala
const PIXELS_PER_METER = 50; // 50 píxeles equivalen a 1 metro
const GRID_SIZE_METERS = 0.5; // Tamaño base de la cuadrícula

// Estado Global de la Aplicación
const appState = {
  mode: 'select', // 'select' | 'wall'
  snapGridMeters: 0.5,
  scale: 1,
  panX: 0,
  panY: 0,
  isPanning: false,
  startPanX: 0,
  startPanY: 0,
  
  // Elementos guardados en el lienzo
  walls: [],
  furniture: [],
  
  // Estado de Selección e Interacción
  selectedElement: null,
  isDrawingWall: false,
  wallStartPoint: null,
  currentMousePos: { x: 0, y: 0 },
  
  // Estado de Arrastre/Rotación
  isDraggingObj: false,
  isRotatingObj: false,
  dragOffset: { x: 0, y: 0 }
};

// Referencias a elementos del DOM
let canvas, ctx, canvasContainer;

// Inicialización de la aplicación
window.addEventListener('DOMContentLoaded', () => {
  canvas = document.getElementById('planCanvas');
  ctx = canvas.getContext('2d');
  canvasContainer = document.getElementById('canvas-container');

  // Ajustar tamaño del canvas al contenedor
  resizeCanvas();
  window.addEventListener('resize', resizeCanvas);

  // Centrar origen de coordenadas al inicio
  appState.panX = canvas.width / 2;
  appState.panY = canvas.height / 2;

  // Registrar eventos de mouse/teclado y UI
  setupCanvasEvents();
  setupUIEvents();

  // Bucle principal de renderizado (60 FPS)
  requestAnimationFrame(renderLoop);
});

// Ajusta dinámicamente la resolución del lienzo
function resizeCanvas() {
  canvas.width = canvasContainer.clientWidth;
  canvas.height = canvasContainer.clientHeight;
}

// Transformación de Coordenadas de Pantalla a Mundo (Metros)
function screenToWorld(screenX, screenY) {
  const worldX = (screenX - appState.panX) / (PIXELS_PER_METER * appState.scale);
  const worldY = (screenY - appState.panY) / (PIXELS_PER_METER * appState.scale);
  return { x: worldX, y: worldY };
}

// Transformación de Coordenadas de Mundo a Pantalla (Píxeles)
function worldToScreen(worldX, worldY) {
  const screenX = worldX * (PIXELS_PER_METER * appState.scale) + appState.panX;
  const screenY = worldY * (PIXELS_PER_METER * appState.scale) + appState.panY;
  return { x: screenX, y: screenY };
}

// Ajuste automático de coordenadas a la rejilla (Snap to Grid)
function snapToGrid(val, step) {
  if (step <= 0) return val;
  return Math.round(val / step) * step;
}

/* ==========================================================================
   CONFIGURACIÓN DE EVENTOS Y BINDINGS DE USUARIO
   ========================================================================== */

function setupCanvasEvents() {
  canvas.addEventListener('mousedown', onMouseDown);
  canvas.addEventListener('mousemove', onMouseMove);
  canvas.addEventListener('mouseup', onMouseUp);
  canvas.addEventListener('wheel', onWheel, { passive: false });
  
  // Desactivar menú contextual con clic derecho para permitir la navegación
  canvas.addEventListener('contextmenu', e => e.preventDefault());

  // Teclas de acceso rápido (Delete / Backspace para borrar selecciones)
  window.addEventListener('keydown', (e) => {
    if ((e.key === 'Delete' || e.key === 'Backspace') && appState.selectedElement) {
      deleteSelectedElement();
    }
  });
}

function setupUIEvents() {
  // Cambio de Modos (Selección vs Dibujo de Muros)
  document.getElementById('btn-mode-select').addEventListener('click', () => setMode('select'));
  document.getElementById('btn-mode-wall').addEventListener('click', () => setMode('wall'));

  // Botones de agregar mobiliario
  document.querySelectorAll('.btn-add-item').forEach(btn => {
    btn.addEventListener('click', (e) => {
      const itemType = e.currentTarget.getAttribute('data-type');
      addFurniture(itemType);
    });
  });

  // Ajustes de rejilla (Snap)
  document.getElementById('select-snap').addEventListener('change', (e) => {
    appState.snapGridMeters = parseFloat(e.target.value);
  });

  // Zoom
  document.getElementById('btn-zoom-in').addEventListener('click', () => zoom(1.15));
  document.getElementById('btn-zoom-out').addEventListener('click', () => zoom(0.85));
  document.getElementById('btn-zoom-reset').addEventListener('click', () => {
    appState.scale = 1;
    appState.panX = canvas.width / 2;
    appState.panY = canvas.height / 2;
  });

  // Guardar y Cargar JSON / Exportar PNG
  document.getElementById('btn-export-png').addEventListener('click', exportToPNG);
  document.getElementById('btn-save-json').addEventListener('click', saveToJSON);
  document.getElementById('input-load-json').addEventListener('change', loadFromJSON);
  document.getElementById('btn-clear').addEventListener('click', () => {
    if (confirm('¿Estás seguro de limpiar todo el proyecto actual?')) {
      appState.walls = [];
      appState.furniture = [];
      appState.selectedElement = null;
      renderPropertiesPanel();
    }
  });
}

function setMode(mode) {
  appState.mode = mode;
  document.querySelectorAll('.btn-mode').forEach(b => {
    b.classList.remove('bg-indigo-600', 'border-indigo-500', 'active');
    b.classList.add('bg-slate-700', 'border-slate-600');
  });

  const activeBtn = mode === 'select' ? document.getElementById('btn-mode-select') : document.getElementById('btn-mode-wall');
  activeBtn.classList.remove('bg-slate-700', 'border-slate-600');
  activeBtn.classList.add('bg-indigo-600', 'border-indigo-500', 'active');

  if (mode !== 'wall') {
    appState.isDrawingWall = false;
    appState.wallStartPoint = null;
  }
}

/* ==========================================================================
   INTERACCIÓN CON MOUSE / EVENTOS DEL CANVAS
   ========================================================================== */

function onMouseDown(e) {
  const rect = canvas.getBoundingClientRect();
  const screenX = e.clientX - rect.left;
  const screenY = e.clientY - rect.top;

  // Clic derecho -> Pan (Desplazamiento del mapa)
  if (e.button === 2) {
    appState.isPanning = true;
    appState.startPanX = screenX - appState.panX;
    appState.startPanY = screenY - appState.panY;
    return;
  }

  // Clic izquierdo
  if (e.button === 0) {
    const worldPos = screenToWorld(screenX, screenY);

    if (appState.mode === 'wall') {
      // Modo Construcción de Muros
      let snappedX = worldPos.x;
      let snappedY = worldPos.y;

      if (appState.snapGridMeters > 0) {
        snappedX = snapToGrid(worldPos.x, appState.snapGridMeters);
        snappedY = snapToGrid(worldPos.y, appState.snapGridMeters);
      }

      if (!appState.isDrawingWall) {
        appState.isDrawingWall = true;
        appState.wallStartPoint = { x: snappedX, y: snappedY };
      } else {
        // Finalizar tramo de muro actual
        const dx = snappedX - appState.wallStartPoint.x;
        const dy = snappedY - appState.wallStartPoint.y;
        
        // Evitar muros de tamaño 0
        if (Math.hypot(dx, dy) > 0.05) {
          appState.walls.push({
            id: 'wall_' + Date.now(),
            x1: appState.wallStartPoint.x,
            y1: appState.wallStartPoint.y,
            x2: snappedX,
            y2: snappedY,
            thickness: 0.15 // 15 cm grosor estándar por defecto
          });
        }
        
        // Encadenar muros consecutivamente
        appState.wallStartPoint = { x: snappedX, y: snappedY };
      }
    } else if (appState.mode === 'select') {
      // Modo Selección y Manipulación
      const clickedObject = findClickedElement(worldPos.x, worldPos.y);

      if (clickedObject) {
        appState.selectedElement = clickedObject;
        appState.isDraggingObj = true;
        
        if (clickedObject.type === 'furniture') {
          appState.dragOffset = {
            x: worldPos.x - clickedObject.item.x,
            y: worldPos.y - clickedObject.item.y
          };
        }
      } else {
        appState.selectedElement = null;
      }
      renderPropertiesPanel();
    }
  }
}

function onMouseMove(e) {
  const rect = canvas.getBoundingClientRect();
  const screenX = e.clientX - rect.left;
  const screenY = e.clientY - rect.top;

  appState.currentMousePos = screenToWorld(screenX, screenY);

  // Actualizar HUD de coordenadas
  document.getElementById('hud-coords').innerText = 
    `X: ${appState.currentMousePos.x.toFixed(2)}m, Y: ${appState.currentMousePos.y.toFixed(2)}m`;

  // Mover vista del Lienzo (Panning)
  if (appState.isPanning) {
    appState.panX = screenX - appState.startPanX;
    appState.panY = screenY - appState.startPanY;
    return;
  }

  // Arrastre de objetos seleccionados
  if (appState.isDraggingObj && appState.selectedElement && appState.selectedElement.type === 'furniture') {
    let newX = appState.currentMousePos.x - appState.dragOffset.x;
    let newY = appState.currentMousePos.y - appState.dragOffset.y;

    if (appState.snapGridMeters > 0) {
      newX = snapToGrid(newX, appState.snapGridMeters);
      newY = snapToGrid(newY, appState.snapGridMeters);
    }

    appState.selectedElement.item.x = newX;
    appState.selectedElement.item.y = newY;
    updatePropertyInputs();
  }
}

function onMouseUp(e) {
  if (e.button === 2) {
    appState.isPanning = false;
  }
  if (e.button === 0) {
    appState.isDraggingObj = false;
  }
}

function onWheel(e) {
  e.preventDefault();
  const zoomFactor = e.deltaY < 0 ? 1.1 : 0.9;
  zoom(zoomFactor);
}

function zoom(factor) {
  const newScale = Math.min(Math.max(appState.scale * factor, 0.2), 5);
  appState.scale = newScale;
  document.getElementById('hud-zoom').innerText = `${Math.round(appState.scale * 100)}%`;
}

/* ==========================================================================
   ALGORITMOS DE SELECCIÓN Y COLISIÓN DE ELEMENTOS 2D
   ========================================================================== */

function findClickedElement(wx, wy) {
  // 1. Probar colisión con mobiliario en orden inverso
  for (let i = appState.furniture.length - 1; i >= 0; i--) {
    const item = appState.furniture[i];
    const dx = wx - item.x;
    const dy = wy - item.y;
    
    // Rotar el punto de prueba en sentido opuesto para calcular AABB en espacio local
    const rad = -item.rotation * Math.PI / 180;
    const localX = dx * Math.cos(rad) - dy * Math.sin(rad);
    const localY = dx * Math.sin(rad) + dy * Math.cos(rad);

    if (Math.abs(localX) <= item.width / 2 && Math.abs(localY) <= item.height / 2) {
      return { type: 'furniture', item: item, index: i };
    }
  }

  // 2. Probar colisión con muros (distancia punto a segmento)
  for (let i = appState.walls.length - 1; i >= 0; i--) {
    const wall = appState.walls[i];
    const dist = pointToSegmentDistance(wx, wy, wall.x1, wall.y1, wall.x2, wall.y2);
    if (dist <= wall.thickness / 2 + 0.1) {
      return { type: 'wall', item: wall, index: i };
    }
  }

  return null;
}

// Algoritmo de distancia mínima entre un punto y un segmento de recta
function pointToSegmentDistance(px, py, x1, y1, x2, y2) {
  const l2 = (x2 - x1) ** 2 + (y2 - y1) ** 2;
  if (l2 === 0) return Math.hypot(px - x1, py - y1);
  let t = ((px - x1) * (x2 - x1) + (py - y1) * (y2 - y1)) / l2;
  t = Math.max(0, Math.min(1, t));
  return Math.hypot(px - (x1 + t * (x2 - x1)), py - (y1 + t * (y2 - y1)));
}

/* ==========================================================================
   CREACIÓN Y GESTIÓN DE ELEMENTOS
   ========================================================================== */

function addFurniture(type) {
  // Colocar en el centro visible actual del viewport
  const centerScreen = { x: canvas.width / 2, y: canvas.height / 2 };
  const worldPos = screenToWorld(centerScreen.x, centerScreen.y);

  let newItem = {
    id: 'furn_' + Date.now(),
    type: type,
    x: snapToGrid(worldPos.x, 0.5),
    y: snapToGrid(worldPos.y, 0.5),
    width: 1.0,
    height: 1.0,
    rotation: 0,
    color: '#6366f1'
  };

  // Tamaños y colores por defecto según tipo de mobiliario
  switch (type) {
    case 'door': newItem.width = 0.9; newItem.height = 0.9; newItem.color = '#f59e0b'; break;
    case 'window': newItem.width = 1.2; newItem.height = 0.2; newItem.color = '#06b6d4'; break;
    case 'checkout': newItem.width = 1.5; newItem.height = 0.8; newItem.color = '#10b981'; break;
    case 'shelf': newItem.width = 2.0; newItem.height = 0.6; newItem.color = '#818cf8'; break;
    case 'desk': newItem.width = 1.4; newItem.height = 0.7; newItem.color = '#c084fc'; break;
    case 'table': newItem.width = 1.2; newItem.height = 1.2; newItem.color = '#fb7185'; break;
    case 'plant': newItem.width = 0.6; newItem.height = 0.6; newItem.color = '#4ade80'; break;
    case 'restroom': newItem.width = 1.5; newItem.height = 1.5; newItem.color = '#38bdf8'; break;
  }

  appState.furniture.push(newItem);
  appState.selectedElement = { type: 'furniture', item: newItem, index: appState.furniture.length - 1 };
  setMode('select');
  renderPropertiesPanel();
}

function deleteSelectedElement() {
  if (!appState.selectedElement) return;

  if (appState.selectedElement.type === 'furniture') {
    appState.furniture.splice(appState.selectedElement.index, 1);
  } else if (appState.selectedElement.type === 'wall') {
    appState.walls.splice(appState.selectedElement.index, 1);
  }

  appState.selectedElement = null;
  renderPropertiesPanel();
}

/* ==========================================================================
   SISTEMA DE RENDERIZADO / PIPELINE GRÁFICO (CANVAS 2D)
   ========================================================================== */

function renderLoop() {
  // Limpiar lienzo completo
  ctx.clearRect(0, 0, canvas.width, canvas.height);

  ctx.save();
  // Aplicar Transformaciones Globales de Cámara (Pan y Zoom)
  ctx.translate(appState.panX, appState.panY);
  ctx.scale(appState.scale, appState.scale);

  // 1. Dibujar Grilla de Coordenadas de Fondo
  drawGrid();

  // 2. Renderizar Muros
  drawWalls();

  // 3. Renderizar Muro en proceso de dibujo
  if (appState.mode === 'wall' && appState.isDrawingWall && appState.wallStartPoint) {
    drawWallPreview();
  }

  // 4. Renderizar Mobiliario
  drawFurniture();

  // 5. Destacar Selección Actual
  drawSelectionHighlight();

  ctx.restore();

  // Continuar ciclo
  requestAnimationFrame(renderLoop);
}

function drawGrid() {
  const meterPx = PIXELS_PER_METER;
  
  // Calcular límites visibles del lienzo en espacio del mundo
  const pMin = screenToWorld(0, 0);
  const pMax = screenToWorld(canvas.width, canvas.height);

  const startX = Math.floor(pMin.x) - 1;
  const endX = Math.ceil(pMax.x) + 1;
  const startY = Math.floor(pMin.y) - 1;
  const endY = Math.ceil(pMax.y) + 1;

  ctx.lineWidth = 1 / appState.scale;

  // Cuadrícula Secundaria (cada 0.5m)
  ctx.strokeStyle = '#1e293b';
  ctx.beginPath();
  for (let x = startX; x <= endX; x += 0.5) {
    ctx.moveTo(x * meterPx, startY * meterPx);
    ctx.lineTo(x * meterPx, endY * meterPx);
  }
  for (let y = startY; y <= endY; y += 0.5) {
    ctx.moveTo(startX * meterPx, y * meterPx);
    ctx.lineTo(endX * meterPx, y * meterPx);
  }
  ctx.stroke();

  // Cuadrícula Principal (cada 1.0m)
  ctx.strokeStyle = '#334155';
  ctx.beginPath();
  for (let x = startX; x <= endX; x += 1.0) {
    ctx.moveTo(x * meterPx, startY * meterPx);
    ctx.lineTo(x * meterPx, endY * meterPx);
  }
  for (let y = startY; y <= endY; y += 1.0) {
    ctx.moveTo(startX * meterPx, y * meterPx);
    ctx.lineTo(endX * meterPx, y * meterPx);
  }
  ctx.stroke();

  // Ejes de Origen Primarios (0,0)
  ctx.lineWidth = 2 / appState.scale;
  ctx.strokeStyle = '#475569';
  ctx.beginPath();
  ctx.moveTo(0, startY * meterPx); ctx.lineTo(0, endY * meterPx);
  ctx.moveTo(startX * meterPx, 0); ctx.lineTo(endX * meterPx, 0);
  ctx.stroke();
}

function drawWalls() {
  const meterPx = PIXELS_PER_METER;

  appState.walls.forEach(wall => {
    const x1 = wall.x1 * meterPx;
    const y1 = wall.y1 * meterPx;
    const x2 = wall.x2 * meterPx;
    const y2 = wall.y2 * meterPx;
    const thickness = wall.thickness * meterPx;

    ctx.save();
    ctx.beginPath();
    ctx.moveTo(x1, y1);
    ctx.lineTo(x2, y2);
    ctx.lineWidth = thickness;
    ctx.strokeStyle = '#94a3b8';
    ctx.lineCap = 'round';
    ctx.stroke();

    // Dibujar cota con la longitud en metros sobre el muro
    const lenMeters = Math.hypot(wall.x2 - wall.x1, wall.y2 - wall.y1);
    const midX = (x1 + x2) / 2;
    const midY = (y1 + y2) / 2;

    ctx.fillStyle = '#f8fafc';
    ctx.font = `${Math.max(10, 12 / appState.scale)}px sans-serif`;
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillText(`${lenMeters.toFixed(2)} m`, midX, midY - (thickness / 2 + 8));

    ctx.restore();
  });
}

function drawWallPreview() {
  const meterPx = PIXELS_PER_METER;
  let targetX = appState.currentMousePos.x;
  let targetY = appState.currentMousePos.y;

  if (appState.snapGridMeters > 0) {
    targetX = snapToGrid(targetX, appState.snapGridMeters);
    targetY = snapToGrid(targetY, appState.snapGridMeters);
  }

  const x1 = appState.wallStartPoint.x * meterPx;
  const y1 = appState.wallStartPoint.y * meterPx;
  const x2 = targetX * meterPx;
  const y2 = targetY * meterPx;

  ctx.save();
  ctx.beginPath();
  ctx.moveTo(x1, y1);
  ctx.lineTo(x2, y2);
  ctx.lineWidth = 0.15 * meterPx;
  ctx.strokeStyle = '#6366f1';
  ctx.setLineDash([6, 6]);
  ctx.stroke();

  // Etiqueta flotante de la longitud actual en construcción
  const len = Math.hypot(targetX - appState.wallStartPoint.x, targetY - appState.wallStartPoint.y);
  ctx.fillStyle = '#818cf8';
  ctx.font = '12px sans-serif';
  ctx.fillText(`${len.toFixed(2)} m`, (x1 + x2) / 2, ((y1 + y2) / 2) - 15);

  ctx.restore();
}

function drawFurniture() {
  const meterPx = PIXELS_PER_METER;

  appState.furniture.forEach(item => {
    ctx.save();
    // Posicionar y rotar el sistema de coordenadas local del elemento
    ctx.translate(item.x * meterPx, item.y * meterPx);
    ctx.rotate(item.rotation * Math.PI / 180);

    const w = item.width * meterPx;
    const h = item.height * meterPx;

    // Renderizado según tipo vectorial
    ctx.fillStyle = item.color;
    ctx.strokeStyle = '#0f172a';
    ctx.lineWidth = 2;

    switch (item.type) {
      case 'door':
        // Arco de apertura de puerta 2D
        ctx.beginPath();
        ctx.arc(-w/2, h/2, w, 0, -Math.PI/2, true);
        ctx.strokeStyle = item.color;
        ctx.setLineDash([3, 3]);
        ctx.stroke();
        ctx.setLineDash([]);
        // Hoja de la puerta
        ctx.fillStyle = item.color;
        ctx.fillRect(-w/2, -h/2, 6, h);
        break;

      case 'window':
        ctx.fillStyle = '#0284c7';
        ctx.fillRect(-w/2, -h/2, w, h);
        ctx.strokeRect(-w/2, -h/2, w, h);
        ctx.beginPath();
        ctx.moveTo(0, -h/2); ctx.lineTo(0, h/2);
        ctx.strokeStyle = '#ffffff';
        ctx.stroke();
        break;

      case 'checkout':
        ctx.fillRect(-w/2, -h/2, w, h);
        ctx.strokeRect(-w/2, -h/2, w, h);
        // Teclado/Pantalla
        ctx.fillStyle = '#0f172a';
        ctx.fillRect(-w/4, -h/4, w/2, h/2);
        break;

      default:
        // Renderizado general en forma de bloque arquitectónico
        ctx.fillRect(-w/2, -h/2, w, h);
        ctx.strokeRect(-w/2, -h/2, w, h);
        break;
    }

    // Indicador visual de orientación frontal (frente del objeto)
    ctx.fillStyle = '#ffffff';
    ctx.beginPath();
    ctx.arc(0, -h/2 + 4, 3, 0, Math.PI * 2);
    ctx.fill();

    ctx.restore();
  });
}

function drawSelectionHighlight() {
  if (!appState.selectedElement) return;

  const meterPx = PIXELS_PER_METER;
  ctx.save();

  if (appState.selectedElement.type === 'furniture') {
    const item = appState.selectedElement.item;
    ctx.translate(item.x * meterPx, item.y * meterPx);
    ctx.rotate(item.rotation * Math.PI / 180);

    const w = item.width * meterPx;
    const h = item.height * meterPx;

    // Caja delimitadora (Bounding Box)
    ctx.strokeStyle = '#38bdf8';
    ctx.lineWidth = 2 / appState.scale;
    ctx.strokeRect(-w/2 - 4, -h/2 - 4, w + 8, h + 8);

    // Tirador superior de rotación
    ctx.beginPath();
    ctx.arc(0, -h/2 - 18, 6 / appState.scale, 0, Math.PI * 2);
    ctx.fillStyle = '#38bdf8';
    ctx.fill();
  } else if (appState.selectedElement.type === 'wall') {
    const wall = appState.selectedElement.item;
    ctx.beginPath();
    ctx.moveTo(wall.x1 * meterPx, wall.y1 * meterPx);
    ctx.lineTo(wall.x2 * meterPx, wall.y2 * meterPx);
    ctx.lineWidth = (wall.thickness + 0.05) * meterPx;
    ctx.strokeStyle = 'rgba(56, 189, 248, 0.4)';
    ctx.stroke();
  }

  ctx.restore();
}

/* ==========================================================================
   PANEL DE PROPIEDADES DINÁMICO DE LA INTERFAZ
   ========================================================================== */

function renderPropertiesPanel() {
  const panel = document.getElementById('properties-panel');

  if (!appState.selectedElement) {
    panel.innerHTML = `
      <div class="text-center text-slate-500 text-sm py-8">
        <i class="fa-solid fa-hand-pointer text-3xl mb-2 text-slate-600 block"></i>
        Selecciona un objeto o muro en el lienzo para ajustar sus propiedades.
      </div>`;
    return;
  }

  const { type, item } = appState.selectedElement;

  if (type === 'furniture') {
    panel.innerHTML = `
      <div class="space-y-3">
        <div class="font-medium text-sm text-indigo-400 capitalize flex justify-between items-center">
          <span>${item.type}</span>
          <button onclick="deleteSelectedElement()" class="text-rose-400 hover:text-rose-300 text-xs">
            <i class="fa-solid fa-trash mr-1"></i>Eliminar
          </button>
        </div>

        <div>
          <label class="text-xs text-slate-400 block mb-1">Ancho (m):</label>
          <input type="number" id="prop-width" step="0.1" value="${item.width}" class="w-full bg-slate-700 border border-slate-600 rounded px-2 py-1 text-sm text-slate-100">
        </div>

        <div>
          <label class="text-xs text-slate-400 block mb-1">Largo / Alto (m):</label>
          <input type="number" id="prop-height" step="0.1" value="${item.height}" class="w-full bg-slate-700 border border-slate-600 rounded px-2 py-1 text-sm text-slate-100">
        </div>

        <div>
          <label class="text-xs text-slate-400 block mb-1">Rotación (°):</label>
          <input type="range" id="prop-rotation" min="0" max="360" value="${item.rotation}" class="w-full">
          <div class="text-right text-xs text-slate-400" id="prop-rotation-val">${item.rotation}°</div>
        </div>

        <div>
          <label class="text-xs text-slate-400 block mb-1">Color de Representación:</label>
          <input type="color" id="prop-color" value="${item.color}" class="w-full h-8 bg-slate-700 border border-slate-600 rounded cursor-pointer">
        </div>
      </div>`;

    // Escuchar eventos de cambio en vivo
    document.getElementById('prop-width').addEventListener('input', (e) => {
      item.width = Math.max(0.1, parseFloat(e.target.value) || 0.1);
    });
    document.getElementById('prop-height').addEventListener('input', (e) => {
      item.height = Math.max(0.1, parseFloat(e.target.value) || 0.1);
    });
    document.getElementById('prop-rotation').addEventListener('input', (e) => {
      item.rotation = parseInt(e.target.value);
      document.getElementById('prop-rotation-val').innerText = `${item.rotation}°`;
    });
    document.getElementById('prop-color').addEventListener('input', (e) => {
      item.color = e.target.value;
    });

  } else if (type === 'wall') {
    const len = Math.hypot(item.x2 - item.x1, item.y2 - item.y1);
    panel.innerHTML = `
      <div class="space-y-3">
        <div class="font-medium text-sm text-indigo-400 flex justify-between items-center">
          <span>Muro Comercial</span>
          <button onclick="deleteSelectedElement()" class="text-rose-400 hover:text-rose-300 text-xs">
            <i class="fa-solid fa-trash mr-1"></i>Eliminar
          </button>
        </div>

        <div>
          <label class="text-xs text-slate-400 block mb-1">Longitud calculada:</label>
          <div class="text-base font-semibold text-slate-200">${len.toFixed(2)} metros</div>
        </div>

        <div>
          <label class="text-xs text-slate-400 block mb-1">Grosor del muro (m):</label>
          <input type="number" id="prop-wall-thickness" step="0.05" min="0.05" max="0.5" value="${item.thickness}" class="w-full bg-slate-700 border border-slate-600 rounded px-2 py-1 text-sm text-slate-100">
        </div>
      </div>`;

    document.getElementById('prop-wall-thickness').addEventListener('input', (e) => {
      item.thickness = Math.max(0.05, parseFloat(e.target.value) || 0.15);
    });
  }
}

function updatePropertyInputs() {
  if (!appState.selectedElement) return;
  if (appState.selectedElement.type === 'furniture') {
    const item = appState.selectedElement.item;
    const wInput = document.getElementById('prop-width');
    const hInput = document.getElementById('prop-height');
    if (wInput) wInput.value = item.width;
    if (hInput) hInput.value = item.height;
  }
}

/* ==========================================================================
   EXPORTACIÓN Y IMPORTACIÓN DE PROYECTOS (JSON / PNG)
   ========================================================================== */

function saveToJSON() {
  const data = {
    version: '1.0',
    timestamp: new Date().toISOString(),
    walls: appState.walls,
    furniture: appState.furniture
  };

  const jsonStr = JSON.stringify(data, null, 2);
  const blob = new Blob([jsonStr], { type: 'application/json' });
  const url = URL.createObjectURL(blob);
  
  const a = document.createElement('a');
  a.href = url;
  a.download = `plano_comercial_${Date.now()}.json`;
  a.click();
  URL.revokeObjectURL(url);
}

function loadFromJSON(e) {
  const file = e.target.files[0];
  if (!file) return;

  const reader = new FileReader();
  reader.onload = (event) => {
    try {
      const data = JSON.parse(event.target.result);
      if (data.walls && data.furniture) {
        appState.walls = data.walls;
        appState.furniture = data.furniture;
        appState.selectedElement = null;
        renderPropertiesPanel();
        alert('¡Plano cargado exitosamente!');
      }
    } catch (err) {
      alert('Error al leer el archivo JSON.');
    }
  };
  reader.readAsText(file);
}

function exportToPNG() {
  // Ocultar temporalmente selecciones e indicadores para una imagen limpia
  const prevSelection = appState.selectedElement;
  appState.selectedElement = null;
  
  renderLoop(); // Forzar renderizado sin selección

  const image = canvas.toDataURL('image/png');
  const a = document.createElement('a');
  a.href = image;
  a.download = `plano_comercial_render_${Date.now()}.png`;
  a.click();

  appState.selectedElement = prevSelection;
}